<?php
define("SERVIDOR", "localhost");
define("USUARIO", "u108244310_mindsyncbanco");
define("SENHA", "Mindsync@2");
define("BANCO", "u108244310_mindsyncbanco");
?>